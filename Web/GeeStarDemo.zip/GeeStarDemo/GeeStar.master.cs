﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;

using D2012.Common.DbCommon;
using D2012.Domain.Services;
using D2012.Common;
using D2012.Domain.Entities;

public partial class GeeStar_GeeStar : System.Web.UI.MasterPage
{
    protected string ulevel;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Session["SYSADMINUSERID"] == null)
        {
           // HttpContext.Current.Response.Redirect("/login.aspx");
        }

        if (yeyRequest.Params("hlogout") == "1")
        {
            doLogout();
           // Response.Redirect("/login.aspx");
        }
        
    }

    public static void doLogout()
    {
        HttpContext.Current.Session["SYSADMINUSERID"] = null;
        HttpContext.Current.Session["SYSADMINUSERNAME"] = null;
        HttpCookie aCookie;
        int iCount = HttpContext.Current.Request.Cookies.Count;
        //清除Cookies
        for (int i = 0; i < iCount; i++)
        {
            aCookie = HttpContext.Current.Request.Cookies[i];
            aCookie.Value = "";
            aCookie.Expires = DateTime.Now.AddYears(-10);
            HttpContext.Current.Response.Cookies.Add(aCookie);
        }
    }
}
