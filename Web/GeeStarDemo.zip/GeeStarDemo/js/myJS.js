﻿$(document).ready(function () {
    function send() {

        var OrderNumber = $("#OrderNumber").val();

      
          //向comet_broadcast.asyn发送请求，消息体为文本框content中的内容，请求接收类为AsnyHandler

          $.post("comet_broadcast.asyn", { OrderNumber: OrderNumber, username:$("#UserName").val(),content: $("#content").val() });

        //清空内容
          $("#content").val("");
          $(".wangEditor-textarea").html("");
    }

    function wait() {
        var OrderNumber = $("#OrderNumber").val();
        $.post("comet_broadcast.asyn", { OrderNumber: OrderNumber, username: $("#UserName").val(), content: "-1" },
         function (data, status) {
             var result = $("#divResult");
             result.html(result.html() + "<br/>" + data);
             document.getElementById("divResult").scrollTop = document.getElementById("divResult").scrollHeight;
             //服务器返回消息,再次立连接
             wait();
         }, "html"
         ).error(function (XMLHttpRequest, textStatus, errorThrown) {
             alert("error");
             alert(XMLHttpRequest.status);
             alert(XMLHttpRequest.readyState);
             alert(textStatus);
         });
    }

    //初始化连接
    wait();


    

    $("#btnSend").click(function () { send(); });
    $("#content").keypress(function (event) {
        if (event.keyCode == 13) {
            send();
        }
    });


});