﻿using D2012.Common.DbCommon;
using D2012.Domain.Services;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class GeeStarDemo_OrderList : System.Web.UI.Page
{
    //ServiceCommon servComm = new ServiceCommon();
    //ConditionComponent ccWhere = new ConditionComponent();
    protected int tcount;
    protected string hddpnumbers;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) {
            Session["UserName"] = "333";
        }
        DataTable dt = new DataTable();
        dt.Columns.Add("OrderNumber");
        dt.Columns.Add("OrderName");
        dt.Rows.Add(dt.NewRow());
        dt.Rows.Add(dt.NewRow());
        dt.Rows.Add(dt.NewRow());
        dt.Rows[0][0] = "10001";
        dt.Rows[0][1] = "义齿定做";
        dt.Rows[1][0] = "10002";
        dt.Rows[1][1] = "牙根定做";
        dt.Rows[2][0] = "10003";
        dt.Rows[2][1] = "牙套定做";
        this.repOrderList.DataSource = dt;
        this.repOrderList.DataBind();
    }
}