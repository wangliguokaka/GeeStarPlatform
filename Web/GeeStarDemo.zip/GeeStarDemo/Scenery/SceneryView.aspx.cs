﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;

using D2012.Common.DbCommon;
using D2012.Domain.Services;
using D2012.Common;
using D2012.Domain.Entities;

public partial class GeeStar_Scenery_SceneryView : PageBase
{
    ServiceCommon servComm = new ServiceCommon();
    ConditionComponent ccWhere = new ConditionComponent();
    protected DDSCENERYTICKET DDSCENERYTICKET = new DDSCENERYTICKET();
    protected DDORDERMANAGEMENT DDORDERMANAGEMENT = new DDORDERMANAGEMENT();
    protected int sellAmount = 0;
    protected decimal sellFee = 0;

    protected void Page_Load(object sender, EventArgs e)
    {

        if (!String.IsNullOrEmpty(yeyRequest.Params("TicketID"))) 
        {
            ccWhere.Clear();
            ccWhere.AddComponent("ISDEL", "0", SearchComponent.Equals, SearchPad.NULL);

            DDSCENERYTICKET = servComm.GetEntity<DDSCENERYTICKET>(yeyRequest.Params("TicketID"), ccWhere);

            ccWhere.Clear();
            ccWhere.AddComponent("ISDEL", "0", SearchComponent.Equals, SearchPad.NULL);
            ccWhere.AddComponent("TicketID",yeyRequest.Params("TicketID"), SearchComponent.Equals, SearchPad.And);
            DataTable dtOrderByScenery = servComm.GetListTop(0, "OrderManagement", ccWhere);

            sellAmount = (int)dtOrderByScenery.Compute("COUNT(OrderID)","");
            sellFee = sellAmount*(decimal)(DDSCENERYTICKET.EntranceFee);
        }

       
    }

}
