﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;

using D2012.Common.DbCommon;
using D2012.Domain.Services;
using D2012.Common;
using D2012.Domain.Entities;

public partial class GeeStar_Scenery_SceneryManage : PageBase
{
    ServiceCommon servComm = new ServiceCommon();
    ConditionComponent ccWhere = new ConditionComponent();
    protected DDSCENERYTICKET DDSCENERYTICKET = new DDSCENERYTICKET();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (String.IsNullOrEmpty(yeyRequest.Params("haddinfo")) && !String.IsNullOrEmpty(yeyRequest.Params("TicketID"))) 
        {
            ccWhere.Clear();
            ccWhere.AddComponent("ISDEL", "0", SearchComponent.Equals, SearchPad.NULL);
            //ccWhere.AddComponent("TicketID", yeyRequest.Params("TicketID"), SearchComponent.Equals, SearchPad.And);
            //向机构收费 向专家付费  
            DDSCENERYTICKET = servComm.GetEntity<DDSCENERYTICKET>(yeyRequest.Params("TicketID"), ccWhere);

        }

       

        if (yeyRequest.Params("haddinfo") == "1")
        {
            if (!String.IsNullOrEmpty(yeyRequest.Params("keyID")))
            {
                DDSCENERYTICKET.TicketID = int.Parse(yeyRequest.Params("keyID"));
                DDSCENERYTICKET.LastModifyIP = Request.UserHostAddress;
                DDSCENERYTICKET.UpdateDate = DateTime.Now;
                DDSCENERYTICKET.UpdateID = this.UserID;
            }
            else {
                DDSCENERYTICKET.CreateIP = Request.UserHostAddress;
                DDSCENERYTICKET.LastModifyIP = Request.UserHostAddress;
                DDSCENERYTICKET.CreateDate = DateTime.Now;
                DDSCENERYTICKET.UpdateDate = DateTime.Now;
                DDSCENERYTICKET.CreateID = this.UserID;
                DDSCENERYTICKET.UpdateID = this.UserID;
            }
            DDSCENERYTICKET.SceneryName = Request["txtSceneyName"];
            DDSCENERYTICKET.AliasName = Request["txtAliasName"];
            DDSCENERYTICKET.PictureName = Request["picfile"];
            DDSCENERYTICKET.SceneryLevel = int.Parse(Request["ddlSceneryLevel"]);
            DDSCENERYTICKET.Address = Request["txtAddress"];
            DDSCENERYTICKET.Lng = Request["txtlng"];
            DDSCENERYTICKET.Lat = Request["txtlat"];
            DDSCENERYTICKET.EntranceFee = decimal.Parse(Request["txtEntranceFee"]);
            DDSCENERYTICKET.OriginalPrice = decimal.Parse(Request["txtOriginalPrice"]);
            DDSCENERYTICKET.SceneryIntrodution = Request["txtSceneryIntrodution"].Replace("\r\n", "");
            DDSCENERYTICKET.PersonCharge = Request["txtPersonCharge"];
            DDSCENERYTICKET.Linkman = Request["txtLinkman"];
            DDSCENERYTICKET.Remark = Request["txtareaRemark"];
            DDSCENERYTICKET.TelephoneNumber = Request["txtTelephoneNumber"];
            DDSCENERYTICKET.ISDEL = false;
           
            if (Request["IsPublish"] == "1") { 
                 DDSCENERYTICKET.IsPublish  = true;
            } else {
                DDSCENERYTICKET.IsPublish = false;
            }
            if (Request["ddlIsRecommend"] == "1") { 
                DDSCENERYTICKET.IsRecommend = true;
            } else {
                DDSCENERYTICKET.IsRecommend = false;
            }
            DDSCENERYTICKET.CreateIP = Request.UserHostAddress;
            DDSCENERYTICKET.CreateDate = DateTime.Now;
            DDSCENERYTICKET.UpdateDate = DateTime.Now;
            
            servComm.AddOrUpdate(DDSCENERYTICKET);
            Response.Redirect("SceneryList.aspx");
        }
    }

}
