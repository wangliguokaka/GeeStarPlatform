﻿using System;
using System.Collections.Generic;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Text;
using System.Data;

using D2012.Common.DbCommon;
using D2012.Domain.Services;
using D2012.Common;
using D2012.Domain.Entities;

public partial class GeeStar_Scenery_CouponTicketManage : PageBase
{
    ServiceCommon servComm = new ServiceCommon();
    ConditionComponent ccWhere = new ConditionComponent();
    protected DDCOUPONTICKETS DDCOUPONTICKETS = new DDCOUPONTICKETS();
    protected DDSCENERYTICKET DDSCENERYTICET = new DDSCENERYTICKET();
    protected DDCOUPONDESIGN DDCOUPONDESIGN = new DDCOUPONDESIGN();
    protected string CheckedTicketID = "";

    protected void Page_Load(object sender, EventArgs e)
    {
        //进入编辑模式
        if (String.IsNullOrEmpty(yeyRequest.Params("haddinfo")) && !String.IsNullOrEmpty(yeyRequest.Params("CouponTicketID"))) 
        {
            ccWhere.Clear();
            ccWhere.AddComponent("ISDEL", "0", SearchComponent.Equals, SearchPad.NULL);
            //ccWhere.AddComponent("TicketID", yeyRequest.Params("TicketID"), SearchComponent.Equals, SearchPad.And);
            DDCOUPONTICKETS = servComm.GetEntity<DDCOUPONTICKETS>(yeyRequest.Params("CouponTicketID"), ccWhere);
             ccWhere.Clear();
             ccWhere.AddComponent("CouponTicketID", yeyRequest.Params("CouponTicketID"), SearchComponent.Equals, SearchPad.NULL);
           DataTable dt = servComm.GetListTop(0, "CouponDesign", ccWhere);
         
           foreach (DataRow dr in dt.Rows)
           {
               CheckedTicketID = CheckedTicketID + ":" + dr["TicketID"].ToString();
           }
           if (CheckedTicketID != "") {
               CheckedTicketID = CheckedTicketID.Substring(1);
           }
        }


        //表单值附加到表格实体中，进行修改或新增数据
        if (yeyRequest.Params("haddinfo") == "1")
        {
            //编辑数据 为主键赋值
            if (!String.IsNullOrEmpty(yeyRequest.Params("keyID")))
            {
                DDCOUPONTICKETS.CouponTicketID = int.Parse(yeyRequest.Params("keyID"));
                DDCOUPONTICKETS.LastModifyIP = Request.UserHostAddress;
                DDCOUPONTICKETS.UpdateDate = DateTime.Now;
                DDCOUPONTICKETS.UpdateID = this.UserID;
                servComm.ExecuteSql(" delete from CouponDesign where CouponTicketID =" + DDCOUPONTICKETS.CouponTicketID);
            }
            else
            {
                DDCOUPONTICKETS.CreateIP = Request.UserHostAddress;
                DDCOUPONTICKETS.LastModifyIP = Request.UserHostAddress;
                DDCOUPONTICKETS.CreateDate = DateTime.Now;
                DDCOUPONTICKETS.UpdateDate = DateTime.Now;
                DDCOUPONTICKETS.CreateID = this.UserID;
                DDCOUPONTICKETS.UpdateID = this.UserID;

            }
            DDCOUPONTICKETS.CouponTicketName = Request["txtCouponName"];
            DDCOUPONTICKETS.PictureName = Request["picfile"];
            DDCOUPONTICKETS.CouponFeeTotal = decimal.Parse(Request["txtCouponFee"]);
            DDCOUPONTICKETS.SceneryIntrodution = Request["txtSceneryIntrodution"].Replace("\r\n", "");
            DDCOUPONTICKETS.ISDEL = false;
            if (Request["ddlIsRecommend"] == "1") { 
                DDCOUPONTICKETS.IsRecommend = true;
            } else {
                DDCOUPONTICKETS.IsRecommend = false;
            }     
            
            int maxInsertID = servComm.AddOrUpdate(DDCOUPONTICKETS);

            //if (!String.IsNullOrEmpty(yeyRequest.Params("keyID"))) {
            //    DDCOUPONDESIGN.CouponTicketID = DDCOUPONTICKETS.CouponTicketID;
            //    DDCOUPONDESIGN.is = true;
            //    DDCOUPONDESIGN.UpdateDate = DateTime.Now;
            //    DDCOUPONDESIGN.UpdateID = this.UserID;
            //    couponTickets.LastModifyIP = Request.UserHostAddress;
            //    servComm.Update(couponTickets);
            //}

            string TicketIDList = yeyRequest.Params("TicketIDList");
            
            string[] tickets = TicketIDList.Split(':');
            for (int i = 0; i < tickets.Length; i++) {
                DDCOUPONDESIGN.CouponTicketID = DDCOUPONTICKETS.CouponTicketID == 0 ? maxInsertID : DDCOUPONTICKETS.CouponTicketID;
                DDCOUPONDESIGN.TicketID = int.Parse(tickets[i]);
                servComm.AddOrUpdate(DDCOUPONDESIGN);
            }

            Response.Redirect("CouponTicketsList.aspx");

        }
        //DDSCENERYTICET
        BindAllSceneryTicket();
    }

    private void BindAllSceneryTicket()
    {
        //repdesign.DataSource = servComm.GetListTop(0, "SceneryTicket", null);
        //repdesign.DataBind();
    }

}
