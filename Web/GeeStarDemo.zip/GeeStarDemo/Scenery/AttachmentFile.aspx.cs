﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using D2012.Common.DbCommon;
using D2012.Domain.Services;
using D2012.Common;
using D2012.Domain.Entities;
public partial class GeeStar_Scenery_AttachmentFile : System.Web.UI.Page
{
    protected string picID;
    protected void Page_Load(object sender, EventArgs e)
    {
        
        picID = yeyRequest.Params("fileid");
        HttpPostedFile file = Request.Files["txtshareF"];

        //如果读取不到文件对象
        if ( file == null)
        {
            if (!String.IsNullOrEmpty(Request["picID"])) { 
                Response.Clear();
                Response.Write("上传失败！");
                Response.End();
            }
        }
        else
        {
            picID = Request["picID"];
            Session["www"] = picID;
            //获取文件夹路径
            string path = Server.MapPath("~/uploadedFiles/"); //网站中有一个 uploadedFiles 文件夹，存储上传来的图片
            //生成文件名（系统要重新生成一个文件名，但注意扩展名要相同。千万不要用中文名称！！！）
            string originalFileName = file.FileName;
            string fileExtension = originalFileName.Substring(originalFileName.LastIndexOf('.'), originalFileName.Length - originalFileName.LastIndexOf('.'));
            string currentFileName = picID + fileExtension;  //例如：可使用“随机数+扩展名”生成文件名
            //生成文件路径
            string imageUrl = path + currentFileName;
            //保存文件
            file.SaveAs(imageUrl);
            string url = Request.Url.GetLeftPart(UriPartial.Authority) + "/uploadedFiles/" + currentFileName;
            Response.Clear();
            Response.Write(url);
            Response.End();
            //-----------------获取文件url-----------------
            //获取img的url地址（如果 file.FileName 有汉字，要进行url编码）
            //string url = Request.Url.GetLeftPart(UriPartial.Authority) + "/uploadedFiles/" + currentFileName;
            //此时 result 已被赋值为“<iframe src="http://localhost:8080/wangEditor_uploadImg_assist.html#ok|图片url地址"></iframe>”
        }

    }
}
