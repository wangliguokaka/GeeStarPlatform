﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using D2012.Common.DbCommon;
using D2012.Domain.Services;
using D2012.Common;
using D2012.Domain.Entities;
public partial class GeeStar_Scenery_CouponTicketsList : PageBase
{
    ServiceCommon servComm = new ServiceCommon();
    ConditionComponent ccWhere = new ConditionComponent();
    protected int tcount;
    protected string hddpnumbers;
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!string.IsNullOrEmpty(yeyRequest.Params("hDelete")))
        {
            DDCOUPONTICKETS couponTickets = new DDCOUPONTICKETS();
            couponTickets.CouponTicketID = Convert.ToInt32(yeyRequest.Params("hDelete"));
            couponTickets.ISDEL = true;
            couponTickets.UpdateDate = DateTime.Now;
            couponTickets.UpdateID = this.UserID; 
            couponTickets.LastModifyIP = Request.UserHostAddress;
            servComm.Update(couponTickets);
        }
        GetCouponTicketsList();

    }

    private void GetCouponTicketsList()
    {

        ccWhere.Clear();
        hddpnumbers = yeyRequest.Params("hpnumbers");
        int iCount = 20;
        if (!string.IsNullOrEmpty(hddpnumbers))
        {
            iCount = Convert.ToInt32(hddpnumbers);
        }
        int iPageIndex = string.IsNullOrEmpty(Request["sPageID"]) ? 1 : Convert.ToInt32(Request["sPageID"]);
        int iPageCount = string.IsNullOrEmpty(Request["sPageNum"]) ? 0 : Convert.ToInt32(Request["sPageNum"]);

        ccWhere.AddComponent("ISDEL", "0", SearchComponent.Equals, SearchPad.NULL);
        //向机构收费 向专家付费  
        string txtCouponTicketsName = yeyRequest.Params("txtCouponTicketsName");
        if (!string.IsNullOrEmpty(txtCouponTicketsName))
        {
            ccWhere.AddComponent("CouponTicketsName ", txtCouponTicketsName, SearchComponent.Like, SearchPad.And);
        }

        servComm.strOrderString = " UpdateDate desc ";
        IList<DDCOUPONTICKETS> ilist = servComm.GetList<DDCOUPONTICKETS>(DDCOUPONTICKETS.STRTABLENAME, "*", DDCOUPONTICKETS.STRKEYNAME, iCount, iPageIndex, iPageCount, ccWhere);
        repCouponTickets.DataSource = ilist;
        repCouponTickets.DataBind();
        pagecut1.iPageNum = servComm.PageCount;
    }
}
